package com;

import java.math.BigDecimal;

public class transformMoney {
    public Object tag = new Object();

    public void transform(Account from, Account to, BigDecimal money) {
        int hash1 = System.identityHashCode(from);
        int hash2 = System.identityHashCode(to);
        if (hash1 > hash2) {
            modify(from, to, money);
        } else if (hash1 > hash2) {
            modify(from, to, money);
        } else {
            modify(from, to, money);
        }
    }

    public void modify(Account from, Account to, BigDecimal money) {
        synchronized (tag) {
            synchronized (from) {
                synchronized (to) {
                    if (from.getMoney().compareTo(money) < 0) {
//                        System.out.println(from.getName() + " - 余额不足 - "+from.getMoney());
                    } else {
                        from.setMoney(from.getMoney().subtract(money));
                        to.setMoney(to.getMoney().add(money));
                    }
                }
            }
        }
        System.out.println(from.getMoney() + " - " + to.getMoney());

    }
}
