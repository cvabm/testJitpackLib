package com;

import android.os.Parcel;
import android.os.Parcelable;

import java.math.BigDecimal;

public class Account implements Parcelable {
    private String name;
    private BigDecimal money;

    public Account(String name, BigDecimal money) {
        this.name = name;
        this.money = money;
    }

    protected Account(Parcel in) {
        name = in.readString();
    }

    public static final Creator<Account> CREATOR = new Creator<Account>() {
        @Override
        public Account createFromParcel(Parcel in) {
            return new Account(in);
        }

        @Override
        public Account[] newArray(int size) {
            return new Account[size];
        }
    };

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {

    }

}
