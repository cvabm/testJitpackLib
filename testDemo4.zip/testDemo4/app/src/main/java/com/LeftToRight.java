package com;

public class LeftToRight {
    private Object a = new Object();
    private Object b = new Object();

    public void leftToRight(int i) {
//        synchronized (a) {
//            synchronized (b) {
                System.out.println("ljg  a to b " + i);
//            }
//        }
    }

    public void rightToLeft(int i) {
        synchronized (a) {
            synchronized (b) {
//                System.out.println("ljg  b to a " + i);
            }
        }
    }
}
