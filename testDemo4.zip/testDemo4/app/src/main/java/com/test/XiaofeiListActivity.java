package com.test;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.androidnetworking.interfaces.OkHttpResponseAndParsedRequestListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import okhttp3.Response;

public class XiaofeiListActivity extends Activity {
    private static final String TAG = "ljg";

    ListView listView;
    Button searchBt;
    EditText phoneET;
    private TextView result;
    Button reset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xiaofei_list);
        listView = findViewById(R.id.xiaofei_list);
        int id = getIntent().getIntExtra("id", 0);
        String phone = getIntent().getStringExtra("phone");

        result = findViewById(R.id.result);
        load(id, phone);
    }

    public void load(int id, String phone) {
        JSONObject ob = new JSONObject();
        try {
            ob.put("id", id);
            ob.put("phone", phone);
            ob.put("page", 1);
            ob.put("limit", 10000);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        AndroidNetworking.post("http://123.182.246.27:8030/xiaofeilog/list")
                .setOkHttpClient(HttpUtils.getOkHttpClient())
                .addJSONObjectBody(ob)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsOkHttpResponseAndObject(xiaofei.class, new OkHttpResponseAndParsedRequestListener() {
                    @Override
                    public void onResponse(Response response, Object o) {
                        final xiaofei person = (xiaofei) o;
                        final List<xiaofei.DataBean> data = person.getData();
                        result.setText("姓名：" + data.get(0).getName() + "   总消费次数：" + data.size());
                        BaseAdapter baseAdapter = new BaseAdapter() {
                            @Override
                            public int getCount() {
                                return data.size();
                            }

                            @Override
                            public Object getItem(int position) {
                                return data.get(position);
                            }

                            @Override
                            public long getItemId(int position) {
                                return position;
                            }

                            @Override
                            public View getView(final int position, View convertView, ViewGroup parent) {
                                String xiaofei = data.get(position).getXiaofei();
                                String time = data.get(position).getSysTime();
                                View inflate = LayoutInflater.from(XiaofeiListActivity.this).inflate(R.layout.xiaofei_item, null);
                                TextView name = inflate.findViewById(R.id.xiaofei_1);
                                name.setText("消费类型：" + xiaofei + "\n 时间：" + time);
                                return inflate;
                            }
                        };

                        listView.setAdapter(baseAdapter);
                    }

                    @Override
                    public void onError(ANError anError) {

                    }
                });
    }
}
