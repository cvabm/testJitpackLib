package com.test;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.androidnetworking.interfaces.OkHttpResponseAndParsedRequestListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import okhttp3.Response;

public class MainActivity extends Activity {
    private static final String TAG = "ljg";

    ListView listView;
    Button searchBt;
    EditText phoneET;
    private TextView result;
    Button reset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listview);
        searchBt = findViewById(R.id.search);
        phoneET = (EditText) findViewById(R.id.phone);
        searchBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a = phoneET.getText().toString().trim();
                load(a);
            }
        });
        load("");
        result = findViewById(R.id.line);
        reset = findViewById(R.id.reset);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                load("");
            }
        });
    }

    public void load(String phone) {
        JSONObject ob = new JSONObject();
        try {
            ob.put("page", 1);
            ob.put("limit", 1000000);
            ob.put("phone", phone);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        AndroidNetworking.post("http://123.182.246.27:8030/user/list")
                .setOkHttpClient(HttpUtils.getOkHttpClient())
                .addJSONObjectBody(ob)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsOkHttpResponseAndObject(Person.class, new OkHttpResponseAndParsedRequestListener() {
                    @Override
                    public void onResponse(Response response, Object o) {
                        final Person person = (Person) o;
                        final List<Person.DataBean> data = person.getData();
                        result.setText("查询结果：" + data.size());
                        BaseAdapter baseAdapter = new BaseAdapter() {
                            @Override
                            public int getCount() {
                                return data.size();
                            }

                            @Override
                            public Object getItem(int position) {
                                return data.get(position);
                            }

                            @Override
                            public long getItemId(int position) {
                                return position;
                            }

                            @Override
                            public View getView(final int position, View convertView, ViewGroup parent) {
                                TextView tv = new TextView(MainActivity.this);//这里只是一个非常简单的例子，我们开发中应该考虑到优化的
                                tv.setText(data.get(position).getMemberName());

                                View inflate = LayoutInflater.from(MainActivity.this).inflate(R.layout.item, null);
                                TextView name = inflate.findViewById(R.id.item_name);
                                Button bt = inflate.findViewById(R.id.item_click);
                                bt.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        Intent intent = new Intent(MainActivity.this, PersonActivity.class);
                                        intent.putExtra("person", data.get(position));
                                        startActivity(intent);
                                    }
                                });
                                name.setText(data.get(position).getMemberName());
                                return inflate;
                            }
                        };

                        listView.setAdapter(baseAdapter);
                    }

                    @Override
                    public void onError(ANError anError) {

                    }
                });
    }
}
