package com.test;

import android.os.Parcel;

import java.io.Serializable;
import java.util.List;

public class Person implements Serializable {
    private Integer code;
    private String msg;
    private List<DataBean> data;
    private Integer count;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public class DataBean implements Serializable {
        private Integer id;
        private String memberName;
        private String phone;
        private Integer chongzhi;
        private Integer jianfacount;
        private Integer ganxicount;
        private Integer xifacount;
        private String addTime;
        private String memberRank;
        private String shopId;

        protected DataBean(Parcel in) {
            if (in.readByte() == 0) {
                id = null;
            } else {
                id = in.readInt();
            }
            memberName = in.readString();
            phone = in.readString();
            if (in.readByte() == 0) {
                chongzhi = null;
            } else {
                chongzhi = in.readInt();
            }
            if (in.readByte() == 0) {
                jianfacount = null;
            } else {
                jianfacount = in.readInt();
            }
            if (in.readByte() == 0) {
                ganxicount = null;
            } else {
                ganxicount = in.readInt();
            }
            if (in.readByte() == 0) {
                xifacount = null;
            } else {
                xifacount = in.readInt();
            }
            addTime = in.readString();
            memberRank = in.readString();
            shopId = in.readString();
        }

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getMemberName() {
            return memberName;
        }

        public void setMemberName(String memberName) {
            this.memberName = memberName;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public Integer getChongzhi() {
            return chongzhi;
        }

        public void setChongzhi(Integer chongzhi) {
            this.chongzhi = chongzhi;
        }

        public Integer getJianfacount() {
            return jianfacount;
        }

        public void setJianfacount(Integer jianfacount) {
            this.jianfacount = jianfacount;
        }

        public Integer getGanxicount() {
            return ganxicount;
        }

        public void setGanxicount(Integer ganxicount) {
            this.ganxicount = ganxicount;
        }

        public Integer getXifacount() {
            return xifacount;
        }

        public void setXifacount(Integer xifacount) {
            this.xifacount = xifacount;
        }

        public String getAddTime() {
            return addTime;
        }

        public void setAddTime(String addTime) {
            this.addTime = addTime;
        }

        public String getMemberRank() {
            return memberRank;
        }

        public void setMemberRank(String memberRank) {
            this.memberRank = memberRank;
        }

        public String getShopId() {
            return shopId;
        }

        public void setShopId(String shopId) {
            this.shopId = shopId;
        }
    }
}
