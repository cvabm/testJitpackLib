package com.test;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.androidnetworking.interfaces.OkHttpResponseAndParsedRequestListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import okhttp3.Response;

public class PersonActivity extends Activity {
    private static final String TAG = "ljg";

    private TextView title;
    private Button chongzhiBt;
    private Button jianfaBt;
    private Person.DataBean person;
    Button record;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.person);
        person = (Person.DataBean) getIntent().getSerializableExtra("person");
        Log.d(TAG, "onCreate: ");
        title = findViewById(R.id.title);
        chongzhiBt = findViewById(R.id.chongzhi);
        jianfaBt = findViewById(R.id.jianfa);
        title.setText("姓名：" + person.getMemberName() + "\n用户Id：" + person.getId() + "\n手机号：" + person.getPhone() + "\n剩余金额:" + person.getChongzhi() + "\n剪发次数:" + person.getJianfacount() +
                "\n干洗次数:" + person.getGanxicount() + "\n洗头次数：" + person.getXifacount());
        chongzhiBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showInputDialog();
            }
        });
        jianfaBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                jianfa();
            }
        });
        record = findViewById(R.id.record);
        record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PersonActivity.this, XiaofeiListActivity.class);
                intent.putExtra("id", person.getId());
                intent.putExtra("phone", person.getPhone());
                startActivity(intent);
            }
        });
    }

    private void showInputDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(PersonActivity.this);
        final View inflate = LayoutInflater.from(this).inflate(R.layout.chongzhi, null);
        builder.setTitle("充值").setView(inflate)
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                EditText money = (EditText) inflate.findViewById(R.id.chong_money);
                EditText jianfa = inflate.findViewById(R.id.chong_jianfa);
                EditText ganxi = inflate.findViewById(R.id.chong_ganxi);
                EditText xitou = inflate.findViewById(R.id.chong_xitou);
                String a = money.getText().toString().trim();
                String b = money.getText().toString().trim();
                String c = money.getText().toString().trim();
                String d = money.getText().toString().trim();
                chong(a, b, c, d);
            }
        });
        builder.show();
    }

    private void jianfa() {
        AndroidNetworking.delete("http://123.182.246.27:8030/user/jianfa?ids=" + person.getId())
                .setOkHttpClient(HttpUtils.getOkHttpClient())
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        String msg = jsonObject.optString("msg");
                        Toast.makeText(PersonActivity.this, msg, Toast.LENGTH_SHORT).show();
                        load(person.getPhone());
                    }

                    @Override
                    public void onError(ANError anError) {
                        Log.d(TAG, "onError: ");
                    }
                });
    }

    private void chong(String a, String b, String c, String d) {
        JSONObject ob = new JSONObject();
        try {
            ob.put("id", person.getId());
            ob.put("chongZhiMoney", a);
            ob.put("xiaoFeiMoney", 0);

            ob.put("chongJianFa", b);
            ob.put("chongGanXi", c);
            ob.put("chongXiFa", d);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        AndroidNetworking.post("http://123.182.246.27:8030/chongzhilog/save")
                .setOkHttpClient(HttpUtils.getOkHttpClient())
                .addJSONObjectBody(ob)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        String msg = jsonObject.optString("msg");
                        Toast.makeText(PersonActivity.this, msg, Toast.LENGTH_SHORT).show();
                        load(person.getPhone());
                    }

                    @Override
                    public void onError(ANError anError) {

                    }
                });
    }


    public void load(String phone) {
        JSONObject ob = new JSONObject();
        try {
            ob.put("page", 1);
            ob.put("limit", 1000000);
            ob.put("phone", phone);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        AndroidNetworking.post("http://123.182.246.27:8030/user/list")
                .setOkHttpClient(HttpUtils.getOkHttpClient())
                .addJSONObjectBody(ob)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsOkHttpResponseAndObject(Person.class, new OkHttpResponseAndParsedRequestListener() {
                    @Override
                    public void onResponse(Response response, Object o) {
                        final Person person1 = (Person) o;
                        final List<Person.DataBean> data = person1.getData();
                        for (int i = 0; i < data.size(); i++) {
                            int id = data.get(i).getId();
                            int id1 = person.getId();
                            if (id == id1) {
                                person = data.get(i);
                                title.setText("姓名：" + person.getMemberName() + "\n用户Id：" + person.getId() + "\n手机号：" + person.getPhone() + "\n剩余金额:" + person.getChongzhi() + "\n剪发次数:" + person.getJianfacount() +
                                        "\n干洗次数:" + person.getGanxicount() + "\n洗头次数：" + person.getXifacount());
                            }
                        }
                    }

                    @Override
                    public void onError(ANError anError) {

                    }
                });
    }

}
