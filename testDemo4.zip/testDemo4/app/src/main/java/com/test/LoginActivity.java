package com.test;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.OkHttpResponseListener;

import okhttp3.Response;

public class LoginActivity extends Activity {
    private static final String TAG = "ljg";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
    }

    public void login(View view) {
        EditText user = (EditText) findViewById(R.id.username);
        EditText pass = (EditText) findViewById(R.id.password);
        String a = user.getText().toString().trim();
        String b = pass.getText().toString().trim();

        AndroidNetworking.post("http://123.182.246.27:8030/login")
                .setOkHttpClient(HttpUtils.getOkHttpClient())
                .addBodyParameter("username", a)
                .addBodyParameter("password", b)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsOkHttpResponse(new OkHttpResponseListener() {
                    @Override
                    public void onResponse(Response response) {
                        int code = response.code();
                        if (response.code() == 200) {
                            startActivity(new Intent(LoginActivity.this, MainActivity.class));
                        }
                    }

                    @Override
                    public void onError(ANError error) {

                    }
                });
    }

}

